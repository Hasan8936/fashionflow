import { useState } from 'react';
import { DashboardHeader } from '@/components/dashboard/DashboardHeader';
import { MetricsOverview } from '@/components/dashboard/MetricsOverview';
import { ForecastChart } from '@/components/dashboard/ForecastChart';
import { ProductTable } from '@/components/dashboard/ProductTable';
import { InventoryAlerts } from '@/components/dashboard/InventoryAlerts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const Index = () => {
  const [selectedProduct, setSelectedProduct] = useState('85123A');

  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader />
      
      <main className="container mx-auto p-6 space-y-8">
        {/* Metrics Overview */}
        <MetricsOverview />
        
        {/* Main Dashboard Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="forecasting">Forecasting</TabsTrigger>
            <TabsTrigger value="inventory">Inventory</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <ForecastChart productCode={selectedProduct} />
              <InventoryAlerts />
            </div>
            <ProductTable onSelectProduct={setSelectedProduct} />
          </TabsContent>
          
          <TabsContent value="forecasting" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Advanced Demand Forecasting</CardTitle>
                <CardDescription>
                  AI-powered predictions with confidence intervals and seasonal analysis
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ForecastChart productCode={selectedProduct} advanced={true} />
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="inventory" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <InventoryAlerts />
              <Card>
                <CardHeader>
                  <CardTitle>Stock Optimization</CardTitle>
                  <CardDescription>
                    Recommended reorder points and safety stock levels
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center p-4 bg-gradient-subtle rounded-lg">
                      <span className="font-medium">Total Products Monitored</span>
                      <span className="text-2xl font-bold text-primary">247</span>
                    </div>
                    <div className="flex justify-between items-center p-4 bg-gradient-subtle rounded-lg">
                      <span className="font-medium">Avg. Forecast Accuracy</span>
                      <span className="text-2xl font-bold text-accent">84.3%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="analytics" className="space-y-6">
            <ProductTable onSelectProduct={setSelectedProduct} showDetailedMetrics={true} />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default Index;