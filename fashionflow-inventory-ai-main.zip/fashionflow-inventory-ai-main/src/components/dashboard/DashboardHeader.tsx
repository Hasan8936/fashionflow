import { Brain, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/button';

export const DashboardHeader = () => {
  return (
    <header className="bg-gradient-primary text-primary-foreground shadow-elevated">
      <div className="container mx-auto px-6 py-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="p-3 bg-white/10 rounded-lg">
              <Brain className="h-8 w-8" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">FashionFlow Intelligence</h1>
              <p className="text-primary-foreground/80 text-lg">
                AI-Powered Demand Forecasting Platform
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <div className="text-sm text-primary-foreground/80">Last Updated</div>
              <div className="font-semibold">{new Date().toLocaleDateString()}</div>
            </div>
            <Button variant="secondary" size="sm" className="bg-white/20 hover:bg-white/30 border-white/20">
              <TrendingUp className="h-4 w-4 mr-2" />
              Refresh Data
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
};