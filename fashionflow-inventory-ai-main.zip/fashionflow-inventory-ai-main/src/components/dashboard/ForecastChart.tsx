import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from 'recharts';

interface ForecastChartProps {
  productCode: string;
  advanced?: boolean;
}

// Mock data representing actual vs predicted demand
const generateMockData = (productCode: string) => {
  const data = [];
  const baseDate = new Date('2024-01-01');
  
  for (let i = 0; i < 30; i++) {
    const date = new Date(baseDate);
    date.setDate(date.getDate() + i);
    
    // Generate realistic demand patterns
    const weekday = date.getDay();
    const isWeekend = weekday === 0 || weekday === 6;
    const baseValue = isWeekend ? 15 : 25;
    const seasonality = Math.sin((i / 30) * 2 * Math.PI) * 5;
    const noise = (Math.random() - 0.5) * 8;
    
    const actual = Math.max(0, Math.round(baseValue + seasonality + noise));
    const predicted = Math.max(0, Math.round(baseValue + seasonality + (Math.random() - 0.5) * 4));
    
    data.push({
      date: date.toISOString().split('T')[0],
      actual: i < 20 ? actual : null, // Only show actual data for past 20 days
      predicted: predicted,
      upper: predicted + Math.round(predicted * 0.2),
      lower: Math.max(0, predicted - Math.round(predicted * 0.2))
    });
  }
  
  return data;
};

export const ForecastChart = ({ productCode, advanced = false }: ForecastChartProps) => {
  const data = generateMockData(productCode);
  
  return (
    <Card className="shadow-card">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Demand Forecast - Product {productCode}</span>
          <div className="flex items-center space-x-2">
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 bg-analytics-blue rounded-full"></div>
              <span className="text-sm text-muted-foreground">Actual</span>
            </div>
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 bg-analytics-teal rounded-full"></div>
              <span className="text-sm text-muted-foreground">Predicted</span>
            </div>
          </div>
        </CardTitle>
        <CardDescription>
          30-day demand forecasting with AI model predictions
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            {advanced ? (
              <AreaChart data={data}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis 
                  dataKey="date" 
                  tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  className="text-muted-foreground"
                />
                <YAxis className="text-muted-foreground" />
                <Tooltip 
                  labelFormatter={(value) => new Date(value).toLocaleDateString()}
                  formatter={(value: number, name: string) => [value, name === 'actual' ? 'Actual' : name === 'predicted' ? 'Predicted' : name]}
                />
                <Area
                  type="monotone"
                  dataKey="upper"
                  stroke="none"
                  fill="hsl(var(--analytics-teal))"
                  fillOpacity={0.1}
                />
                <Area
                  type="monotone"
                  dataKey="lower"
                  stroke="none"
                  fill="white"
                  fillOpacity={1}
                />
                <Line
                  type="monotone"
                  dataKey="actual"
                  stroke="hsl(var(--analytics-blue))"
                  strokeWidth={2}
                  dot={{ fill: "hsl(var(--analytics-blue))", r: 3 }}
                  connectNulls={false}
                />
                <Line
                  type="monotone"
                  dataKey="predicted"
                  stroke="hsl(var(--analytics-teal))"
                  strokeWidth={2}
                  dot={{ fill: "hsl(var(--analytics-teal))", r: 3 }}
                  strokeDasharray="5 5"
                />
              </AreaChart>
            ) : (
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis 
                  dataKey="date" 
                  tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  className="text-muted-foreground"
                />
                <YAxis className="text-muted-foreground" />
                <Tooltip 
                  labelFormatter={(value) => new Date(value).toLocaleDateString()}
                  formatter={(value: number, name: string) => [value, name === 'actual' ? 'Actual' : 'Predicted']}
                />
                <Line
                  type="monotone"
                  dataKey="actual"
                  stroke="hsl(var(--analytics-blue))"
                  strokeWidth={2}
                  dot={{ fill: "hsl(var(--analytics-blue))", r: 3 }}
                  connectNulls={false}
                />
                <Line
                  type="monotone"
                  dataKey="predicted"
                  stroke="hsl(var(--analytics-teal))"
                  strokeWidth={2}
                  dot={{ fill: "hsl(var(--analytics-teal))", r: 3 }}
                  strokeDasharray="5 5"
                />
              </LineChart>
            )}
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};