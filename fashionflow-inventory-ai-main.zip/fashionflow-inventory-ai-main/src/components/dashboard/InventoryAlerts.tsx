import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertTriangle, Package, TrendingDown, Clock } from 'lucide-react';

const inventoryData = [
  {
    productCode: '85123A',
    description: 'WHITE HANGING HEART T-LIGHT HOLDER',
    currentStock: 45,
    forecastMean: 23.5,
    safetyStock: 12.5,
    reorderPoint: 177.0,
    daysOfStock: 1.9,
    status: 'CRITICAL'
  },
  {
    productCode: '22423',
    description: 'REGENCY CAKESTAND 3 TIER',
    currentStock: 89,
    forecastMean: 18.2,
    safetyStock: 9.8,
    reorderPoint: 137.2,
    daysOfStock: 4.9,
    status: 'LOW'
  },
  {
    productCode: '47566',
    description: 'PARTY BUNTING',
    currentStock: 156,
    forecastMean: 15.7,
    safetyStock: 11.2,
    reorderPoint: 121.1,
    daysOfStock: 9.9,
    status: 'MEDIUM'
  },
  {
    productCode: '20725',
    description: 'LUNCH BAG RED SPOTTY',
    currentStock: 234,
    forecastMean: 12.8,
    safetyStock: 8.4,
    reorderPoint: 98.0,
    daysOfStock: 18.3,
    status: 'HIGH'
  }
];

export const InventoryAlerts = () => {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'CRITICAL':
        return (
          <Badge className="bg-critical/10 text-critical hover:bg-critical/20">
            <AlertTriangle className="h-3 w-3 mr-1" />
            Critical
          </Badge>
        );
      case 'LOW':
        return (
          <Badge className="bg-warning/10 text-warning-foreground hover:bg-warning/20">
            <TrendingDown className="h-3 w-3 mr-1" />
            Low
          </Badge>
        );
      case 'MEDIUM':
        return (
          <Badge className="bg-analytics-blue/10 text-analytics-blue hover:bg-analytics-blue/20">
            <Package className="h-3 w-3 mr-1" />
            Medium
          </Badge>
        );
      case 'HIGH':
        return (
          <Badge className="bg-success/10 text-success hover:bg-success/20">
            <Clock className="h-3 w-3 mr-1" />
            High
          </Badge>
        );
      default:
        return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'CRITICAL':
        return 'border-l-critical';
      case 'LOW':
        return 'border-l-warning';
      case 'MEDIUM':
        return 'border-l-analytics-blue';
      case 'HIGH':
        return 'border-l-success';
      default:
        return 'border-l-muted';
    }
  };

  const criticalItems = inventoryData.filter(item => item.status === 'CRITICAL');
  const lowItems = inventoryData.filter(item => item.status === 'LOW');

  return (
    <Card className="shadow-card">
      <CardHeader>
        <CardTitle className="flex items-center">
          <AlertTriangle className="h-5 w-5 mr-2 text-warning" />
          Inventory Alerts
        </CardTitle>
        <CardDescription>
          Real-time stock monitoring with AI-powered reorder recommendations
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Critical Alerts */}
        {criticalItems.length > 0 && (
          <Alert className="border-critical bg-critical/5">
            <AlertTriangle className="h-4 w-4 text-critical" />
            <AlertDescription className="text-critical">
              <strong>{criticalItems.length} products</strong> require immediate restocking
            </AlertDescription>
          </Alert>
        )}

        {/* Low Stock Alert */}
        {lowItems.length > 0 && (
          <Alert className="border-warning bg-warning/5">
            <Package className="h-4 w-4 text-warning-foreground" />
            <AlertDescription className="text-warning-foreground">
              <strong>{lowItems.length} products</strong> are running low on stock
            </AlertDescription>
          </Alert>
        )}

        {/* Inventory List */}
        <div className="space-y-3">
          {inventoryData.map((item, index) => (
            <div
              key={index}
              className={`border-l-4 ${getStatusColor(item.status)} bg-gradient-subtle p-4 rounded-r-lg`}
            >
              <div className="flex items-center justify-between mb-2">
                <div>
                  <div className="font-medium text-sm">{item.productCode}</div>
                  <div className="text-xs text-muted-foreground truncate max-w-[200px]">
                    {item.description}
                  </div>
                </div>
                {getStatusBadge(item.status)}
              </div>
              
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="text-muted-foreground">Current Stock:</span>
                  <span className="ml-1 font-medium">{item.currentStock}</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Days Left:</span>
                  <span className="ml-1 font-medium">{item.daysOfStock.toFixed(1)}</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Daily Demand:</span>
                  <span className="ml-1 font-medium">{item.forecastMean.toFixed(1)}</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Reorder Point:</span>
                  <span className="ml-1 font-medium">{item.reorderPoint.toFixed(0)}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};