import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

interface ProductTableProps {
  onSelectProduct: (productCode: string) => void;
  showDetailedMetrics?: boolean;
}

// Mock product data based on the FashionFlow analysis
const mockProducts = [
  {
    code: '85123A',
    description: 'WHITE HANGING HEART T-LIGHT HOLDER',
    totalSales: 1854.32,
    quantity: 1632,
    mae: 2.45,
    rmse: 3.21,
    r2: 0.847,
    mape: 12.3,
    status: 'Good'
  },
  {
    code: '22423',
    description: 'REGENCY CAKESTAND 3 TIER',
    totalSales: 1673.88,
    quantity: 1458,
    mae: 3.12,
    rmse: 4.56,
    r2: 0.623,
    mape: 18.7,
    status: 'Good'
  },
  {
    code: '47566',
    description: 'PARTY BUNTING',
    totalSales: 1456.20,
    quantity: 1296,
    mae: 4.23,
    rmse: 6.78,
    r2: 0.445,
    mape: 25.4,
    status: 'Poor'
  },
  {
    code: '20725',
    description: 'LUNCH BAG RED SPOTTY',
    totalSales: 1398.45,
    quantity: 1184,
    mae: 2.87,
    rmse: 3.98,
    r2: 0.756,
    mape: 15.2,
    status: 'Good'
  },
  {
    code: '84029G',
    description: 'KNITTED UNION FLAG HOT WATER BOTTLE',
    totalSales: 1287.90,
    quantity: 1067,
    mae: 3.45,
    rmse: 5.23,
    r2: 0.598,
    mape: 21.8,
    status: 'Good'
  }
];

export const ProductTable = ({ onSelectProduct, showDetailedMetrics = false }: ProductTableProps) => {
  const getStatusBadge = (status: string) => {
    return status === 'Good' ? (
      <Badge className="bg-success/10 text-success hover:bg-success/20">Good</Badge>
    ) : (
      <Badge variant="destructive" className="bg-destructive/10 text-destructive hover:bg-destructive/20">Poor</Badge>
    );
  };

  return (
    <Card className="shadow-card">
      <CardHeader>
        <CardTitle>Product Performance Analysis</CardTitle>
        <CardDescription>
          Top performing products with forecasting metrics and accuracy scores
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Product Code</TableHead>
              <TableHead>Description</TableHead>
              <TableHead className="text-right">Total Sales</TableHead>
              <TableHead className="text-right">Quantity</TableHead>
              {showDetailedMetrics && (
                <>
                  <TableHead className="text-right">MAE</TableHead>
                  <TableHead className="text-right">R²</TableHead>
                  <TableHead className="text-right">MAPE</TableHead>
                </>
              )}
              <TableHead>Status</TableHead>
              <TableHead>Action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {mockProducts.map((product) => (
              <TableRow key={product.code} className="hover:bg-muted/50">
                <TableCell className="font-mono font-medium">{product.code}</TableCell>
                <TableCell className="max-w-[200px] truncate">{product.description}</TableCell>
                <TableCell className="text-right font-medium">
                  £{product.totalSales.toFixed(2)}
                </TableCell>
                <TableCell className="text-right">{product.quantity.toLocaleString()}</TableCell>
                {showDetailedMetrics && (
                  <>
                    <TableCell className="text-right font-mono">{product.mae}</TableCell>
                    <TableCell className="text-right font-mono">{product.r2}</TableCell>
                    <TableCell className="text-right font-mono">{product.mape}%</TableCell>
                  </>
                )}
                <TableCell>{getStatusBadge(product.status)}</TableCell>
                <TableCell>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onSelectProduct(product.code)}
                    className="hover:bg-primary hover:text-primary-foreground"
                  >
                    View Forecast
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
};