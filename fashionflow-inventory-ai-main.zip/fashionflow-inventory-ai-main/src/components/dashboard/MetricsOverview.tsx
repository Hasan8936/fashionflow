import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, Package, AlertTriangle } from 'lucide-react';

const metrics = [
  {
    title: 'Total Revenue',
    value: '£2.4M',
    change: '+12.5%',
    trend: 'up',
    icon: TrendingUp,
    color: 'text-analytics-blue'
  },
  {
    title: 'Products Analyzed',
    value: '247',
    change: '+8 new',
    trend: 'up',
    icon: Package,
    color: 'text-analytics-teal'
  },
  {
    title: 'Forecast Accuracy',
    value: '84.3%',
    change: '+2.1%',
    trend: 'up',
    icon: TrendingUp,
    color: 'text-analytics-green'
  },
  {
    title: 'Critical Stock',
    value: '12',
    change: '-3',
    trend: 'down',
    icon: AlertTriangle,
    color: 'text-critical'
  }
];

export const MetricsOverview = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {metrics.map((metric, index) => {
        const Icon = metric.icon;
        const isPositive = metric.trend === 'up';
        
        return (
          <Card key={index} className="shadow-card hover:shadow-elevated transition-shadow duration-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {metric.title}
              </CardTitle>
              <Icon className={`h-5 w-5 ${metric.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground mb-2">
                {metric.value}
              </div>
              <Badge
                variant={isPositive ? 'default' : 'destructive'}
                className={`text-xs ${
                  isPositive 
                    ? 'bg-success/10 text-success hover:bg-success/20' 
                    : 'bg-destructive/10 text-destructive hover:bg-destructive/20'
                }`}
              >
                {isPositive ? (
                  <TrendingUp className="h-3 w-3 mr-1" />
                ) : (
                  <TrendingDown className="h-3 w-3 mr-1" />
                )}
                {metric.change}
              </Badge>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
};